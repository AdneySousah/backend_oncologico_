import React from 'react';
import { AuthProvider } from './src/hooks/AuthContext';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import FlashMessage from "react-native-flash-message";
import RoutesApp from './src/routes/routesApp';
import { ProfileProvider } from './src/hooks/ProfileContext';

export default function App() {
    return (
        <AuthProvider>
            <ProfileProvider>
                <SafeAreaProvider>
                    <FlashMessage position='top' statusBarHeight={30} floating={true} />
                    <RoutesApp />
                </SafeAreaProvider>
            </ProfileProvider>
        </AuthProvider>
    );
}
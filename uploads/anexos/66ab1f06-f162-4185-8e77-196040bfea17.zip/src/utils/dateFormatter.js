// src/utils/dateFormatter.js

// 1. Aplica a máscara DD-MM-YYYY enquanto o usuário digita
export const maskDate = (value) => {
  return value
    .replace(/\D/g, "") // Remove tudo que não é número
    .replace(/(\d{2})(\d)/, "$1-$2") // Coloca o primeiro traço após os 2 primeiros números
    .replace(/(\d{2})(\d)/, "$1-$2") // Coloca o segundo traço após os próximos 2 números
    .replace(/(\d{4})(\d+?)$/, "$1"); // Limita a 8 números (4 para o ano no final)
};

// 2. Converte DD-MM-YYYY para YYYY-MM-DD para o banco de dados
export const formatDateToBackend = (date) => {
  if (!date) return null;
  const [day, month, year] = date.split("-");
  return `${year}-${month}-${day}`;
};
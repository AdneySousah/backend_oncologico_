import { StyleSheet, Platform } from 'react-native';

export const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        backgroundColor: '#FFFFFF',
        height: 70,
        borderTopLeftRadius: 25,
        borderTopRightRadius: 25,
        
        // Sombra para Android
        elevation: 20,
        
        // Sombra para iOS
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,

        // Ajuste para iPhones com notch
        paddingBottom: Platform.OS === 'ios' ? 20 : 0,
        alignItems: 'center',
        justifyContent: 'space-around',
        position: 'absolute',
        bottom: 0,
        width: '100%',
    },
    tabButton: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    label: {
        fontSize: 10,
        marginTop: 4,
        fontWeight: '600',
    },
    activeIndicator: {
        position: 'absolute',
        top: -10,
        width: 20,
        height: 3,
        backgroundColor: '#4CAF50', // Ou seu themes.colors.primary
        borderRadius: 2,
    }
});
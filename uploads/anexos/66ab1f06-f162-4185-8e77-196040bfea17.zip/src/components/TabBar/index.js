import React from 'react';
import { View, TouchableOpacity, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { styles } from './styles';
import { themes } from '../../styles/themes';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function TabBar({ state, descriptors, navigation }) {
    const insets = useSafeAreaInsets();
    return (
        <View style={[styles.container,
        {paddingBottom: insets.bottom > 0 ? insets.bottom : 10, height: 60 + insets.bottom }
    ]}
     
        >
            {state.routes.map((route, index) => {
                const { options } = descriptors[route.key];
                const label = options.tabBarLabel !== undefined ? options.tabBarLabel : route.name;
                const isFocused = state.index === index;

                const onPress = () => {
                    const event = navigation.emit({
                        type: 'tabPress',
                        target: route.key,
                        canPreventDefault: true,
                    });

                    if (!isFocused && !event.defaultPrevented) {
                        navigation.navigate(route.name);
                    }
                };

                // Lógica simples para escolher o ícone baseado no nome da rota
                let iconName;
                if (route.name === 'Dashboard') iconName = isFocused ? 'home' : 'home-outline';
                else if (route.name === 'Refeição') iconName = isFocused ? 'camera' : 'camera-outline'; // ÍCONE NOVO
                else if (route.name === 'Diário') iconName = isFocused ? 'calendar' : 'calendar-outline';
                else if (route.name === 'Perfil') iconName = isFocused ? 'person' : 'person-outline';

                return (
                    <TouchableOpacity
                        key={index}
                        onPress={onPress}
                        style={styles.tabButton}
                        activeOpacity={0.7}
                    >
                        <Ionicons 
                            name={iconName} 
                            size={24} 
                            color={isFocused ? themes.colors.primary : '#8E8E93'} 
                        />
                        <Text style={[
                            styles.label, 
                            { color: isFocused ? themes.colors.primary : '#8E8E93' }
                        ]}>
                            {label}
                        </Text>
                        
                        {/* Indicador visual de aba ativa (opcional) */}
                        {isFocused && <View style={styles.activeIndicator} />}
                    </TouchableOpacity>
                );
            })}
        </View>
    );
}
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    horizontalScroll: {
        paddingLeft: 20,
        marginBottom: 20,
    },
    macroItem: {
        alignItems: 'center',
        marginRight: 20, // Espaçamento entre os macros
        width: 75,
    },
    circleWrapper: {
        width: 65,
        height: 65,
        justifyContent: 'center',
        alignItems: 'center',
    },
    baseCircle: {
        position: 'absolute',
        width: 65,
        height: 65,
        borderRadius: 32.5,
        borderWidth: 6,
    },
    progressCircle: {
        position: 'absolute',
        width: 65,
        height: 65,
        borderRadius: 32.5,
        borderWidth: 6,
        borderTopColor: 'transparent',
        borderLeftColor: 'transparent',
        transform: [{ rotate: '45deg' }]
    },
    textInside: {
        alignItems: 'center',
    },
    valueText: {
        fontSize: 12,
        fontWeight: 'bold',
        color: '#333',
    },
    label: {
        marginTop: 6,
        fontSize: 11,
        fontWeight: 'bold',
        textTransform: 'uppercase',
    },
    targetMini: {
        fontSize: 9,
        color: '#999',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
        marginLeft: 20,
        marginBottom: 15,
        marginTop: 20
    }
});
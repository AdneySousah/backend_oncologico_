import React, { useEffect, useRef } from 'react';
import { View, Animated, Text } from 'react-native';
import { styles } from './styles';

export default function MacroCircle({ label, value, target, color, percentage }) {
    const animatedValue = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.timing(animatedValue, {
            toValue: percentage > 100 ? 100 : percentage,
            duration: 1000,
            useNativeDriver: false,
        }).start();
    }, [percentage]);

    return (
        <View style={styles.macroItem}>
            <View style={styles.circleWrapper}>
                {/* Círculo de Fundo */}
                <View style={[styles.baseCircle, { borderColor: '#E0E0E0' }]} />
                
                {/* Círculo de Progresso */}
                <View style={[styles.progressCircle, { borderColor: color, opacity: (percentage / 100) + 0.3 }]} />
                
                <View style={styles.textInside}>
                    <Text style={styles.valueText}>{value}g</Text>
                </View>
            </View>
            <Text style={[styles.label, { color: color }]}>{label}</Text>
            <Text style={styles.targetMini}>Meta: {target}g</Text>
        </View>
    );
}
import { StyleSheet } from "react-native";

import { themes } from "../../styles/themes";

export const styles = StyleSheet.create({
  button: {
    backgroundColor: themes.colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20
  },
  buttonText: {
    color: themes.colors.surface,
    fontWeight: 'bold'

  }
})
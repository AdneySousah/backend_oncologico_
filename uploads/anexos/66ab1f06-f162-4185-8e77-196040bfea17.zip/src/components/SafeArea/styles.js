import { StyleSheet } from "react-native";
import { themes } from '../../styles/themes'; 


export const styles = StyleSheet.create({
  container: {
    flex: 1, // Faz o layout ocupar a tela toda
    backgroundColor: themes.secondary, // Usa o cinza claro/branco do seu tema
    paddingHorizontal: 20, // Dá uma respiração nas laterais do app
  
  },
});
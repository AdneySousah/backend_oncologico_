
import { SafeAreaView } from 'react-native-safe-area-context';

import { styles } from './styles';

export default function PageLayout({ children }) {
  return (
    // O edges=['top', 'left', 'right'] evita que ele adicione espaço vazio no fundo do app
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      {children}
    </SafeAreaView>
  );
}


import { StyleSheet } from "react-native";
import { themes } from "../../styles/themes";


export const styles = StyleSheet.create({
       loadStyle:{
        flex:1,
       
        justifyContent:'center',
        alignItems:'center'

    },
    loadCircleStyle:{
     
        width:50,
        height:50,
        borderRadius:25,
        borderWidth:10,
        borderColor:themes.colors.placeholder,
        borderTopColor:themes.colors.textLight,
        borderLeftColor: themes.colors.textLight,
        marginBottom:7
    },
  
})
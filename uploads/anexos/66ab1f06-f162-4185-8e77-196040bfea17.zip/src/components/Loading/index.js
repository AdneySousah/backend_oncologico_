
import { useEffect, useRef } from 'react';
import {  View,  Animated, Easing, Text } from 'react-native';
import { styles } from './styles';

export default function Loading() {

            const rotation = useRef(new Animated.Value(0)).current
        /* criando animação de loading */
        useEffect(() => {
            const startAnimation = () => {
                Animated.loop(
                    Animated.timing(rotation, {
                        toValue: 1,
                        duration: 1000,
                        easing: Easing.linear,
                        useNativeDriver: true
                    })
                ).start()
            }
            startAnimation()
        }, [])
    
        const spin = rotation.interpolate({
            inputRange: [0, 1],
            outputRange: ['0deg', '360deg']
        })
    return (
        <View style={styles.loadStyle}>
            <Animated.View style={[styles.loadCircleStyle,
            { transform: [{ rotate: spin }] }
            ]}>

            </Animated.View>
            <Text>Carregando</Text>
    
        </View>
    )
}
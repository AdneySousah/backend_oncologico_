import { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';
import api from '../services/api';

const ProfileContext = createContext({});

export function ProfileProvider({ children }) {
    const { user } = useAuth(); // Pega o usuário do Auth
    const [profileData, setProfileData] = useState(null);
    const [loadingProfile, setLoadingProfile] = useState(true);

    // Busca os dados do perfil sempre que o usuário logar
    useEffect(() => {
        if (user) {
            loadProfile();
        }
    }, [user]);

    async function loadProfile() {
        try {
            setLoadingProfile(true);
            const response = await api.get(`/profiles/${user.id}`);
            setProfileData(response.data);
        } catch (error) {
            console.error("Erro ao carregar perfil", error);
        } finally {
            setLoadingProfile(false);

        }
    }

    async function createProfile(profileData) {


        try {
            const { data } = await api.post('/create-profile', {
                userId: user.id,
                profileData

            })
            setProfileData(data)
            console.log(data)
        }
        catch (err) {
            console.error(err.response?.data || err.message)
        }

    }

    
    async function updateStats(weight, activityLevel) {
        try {
            // Rota de update que você criou no controller
            const { data } = await api.put('/profiles', {
                weight: Number(weight),
                activity_level: activityLevel
            });
            setProfileData(data); // Atualiza o dashboard com novo IMC/TMB automaticamente
        } catch (err) {
            console.error("Erro ao atualizar stats:", err.response?.data || err.message);
        }
    }

    return (
        <ProfileContext.Provider value={{ profileData, loadingProfile, updateStats, createProfile }}>
            {children}
        </ProfileContext.Provider>
    );
}

export const useProfile = () => useContext(ProfileContext);
import { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api'; // Sua instância do Axios

const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const [awaitTime, setAwaitTime] = useState(false)

  // Verifica se há um usuário logado ao iniciar o app
  useEffect(() => {
    async function loadStorageData() {
      const storageUser = await AsyncStorage.getItem('@Auth:user');
      const storageToken = await AsyncStorage.getItem('@Auth:token');

      if (storageUser && storageToken) {
        // Define o token no header do axios para futuras requisições
        api.defaults.headers.Authorization = `Bearer ${storageToken}`;
        setUser(JSON.parse(storageUser));
      }
      setLoading(false);
    }
    loadStorageData();
  }, []);

  async function login(email, password) {

    try {
      setAwaitTime(true)
      const response = await api.post('/session', { email, password });

      const { user, token } = response.data;

      // Salva no estado
      setUser(user);

      // Define o token no Axios
      api.defaults.headers.Authorization = `Bearer ${token}`;

      // Persiste os dados no dispositivo
      await AsyncStorage.setItem('@Auth:user', JSON.stringify(user));
      await AsyncStorage.setItem('@Auth:token', token);
      
    } catch (error) {
      console.error("Erro no login:", error.response?.data || error.message);

      throw error; // Lança o erro para o componente tratar (ex: mostrar alerta)
    }
    finally {
      setAwaitTime(false)
    }
  }

  function logout() {
    AsyncStorage.clear().then(() => {
      setUser(null);
    });
  }

  return (
    <AuthContext.Provider value={{ signed: !!user, user, login, logout, loading, awaitTime }}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook personalizado para facilitar o uso
export function useAuth() {
  const context = useContext(AuthContext);
  return context;
}
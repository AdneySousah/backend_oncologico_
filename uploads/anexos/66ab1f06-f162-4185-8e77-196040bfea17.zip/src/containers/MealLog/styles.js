import { StyleSheet, Dimensions } from 'react-native';
const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8F9FA', padding: 25, paddingTop: 60 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 30, backgroundColor: '#FFF' },
    header: { fontSize: 26, fontWeight: 'bold', color: '#333', marginBottom: 20 },
    
    uploadArea: { 
        width: '100%', height: 350, backgroundColor: '#FFF', borderRadius: 30, 
        borderWidth: 2, borderColor: '#EEE', borderStyle: 'dashed', 
        justifyContent: 'center', alignItems: 'center', overflow: 'hidden' 
    },
    imgPreview: { width: '100%', height: '100%' },
    empty: { alignItems: 'center' },
    emptyTxt: { color: '#BBB', marginTop: 10, fontSize: 16 },
    
    row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 30 },
    btnSec: { width: '45%', paddingVertical: 18, borderRadius: 15, borderWidth: 1, borderColor: '#4CAF50', alignItems: 'center' },
    btnSecTxt: { color: '#4CAF50', fontWeight: 'bold' },
    btnMain: { width: '50%', backgroundColor: '#4CAF50', paddingVertical: 18, borderRadius: 15, alignItems: 'center' },
    btnText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },

    statusTitle: { fontSize: 22, fontWeight: 'bold', color: '#333', marginBottom: 40 },
    timeline: { width: '100%' },
    stepItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
    dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#F0F0F0', marginRight: 15 },
    dotActive: { backgroundColor: '#4CAF50', transform: [{ scale: 1.3 }] },
    stepText: { fontSize: 16, color: '#DDD' },
    stepActive: { color: '#444', fontWeight: 'bold' },

    containerResult: { flex: 1, backgroundColor: '#FFF' },
    imgFull: { width: '100%', height: 300 },
    cardResult: { marginTop: -40, backgroundColor: '#FFF', borderTopLeftRadius: 40, borderTopRightRadius: 40, padding: 30 },
    aiTitle: { fontSize: 22, fontWeight: 'bold', color: '#333', marginBottom: 10 },
    aiDesc: { fontSize: 15, color: '#666', lineHeight: 22, fontStyle: 'italic', marginBottom: 30 },
    subTitle: { fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 15 },
    
    itemRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
    itemName: { fontSize: 16, color: '#444', textTransform: 'capitalize' },
    itemLine: { flex: 1, height: 1, backgroundColor: '#F0F0F0', marginHorizontal: 10, borderStyle: 'dotted' },
    itemWeight: { fontSize: 16, fontWeight: 'bold', color: '#4CAF50' },

    divider: { height: 1, backgroundColor: '#F0F0F0', marginVertical: 20 },

    grid: { flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap' },
    box: { width: '22%', backgroundColor: '#F8F9FA', padding: 12, borderRadius: 15, alignItems: 'center', marginBottom: 10 },
    boxVal: { fontSize: 16, fontWeight: 'bold' },
    boxLab: { fontSize: 10, color: '#999', textTransform: 'uppercase', marginTop: 2 },
    
    btnDone: { backgroundColor: '#222', paddingVertical: 20, borderRadius: 20, alignItems: 'center', marginTop: 40, width: '100%' },
    btnCancel: { padding: 15, alignItems: 'center', marginTop: 10 },
    btnCancelText: { color: '#FF5252', fontWeight: 'bold' }
});
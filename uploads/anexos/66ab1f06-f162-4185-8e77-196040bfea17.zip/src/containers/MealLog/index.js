import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, Image, ActivityIndicator, ScrollView, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import api from '../../services/api'; 
import { styles } from './styles';
import { useProfile } from '../../hooks/ProfileContext';

export default function MealLog({ navigation }) {
    const [image, setImage] = useState(null);
    const [status, setStatus] = useState('idle'); // idle | analyzing | result
    const [result, setResult] = useState(null);
    const { refreshProfile } = useProfile();

    const [step, setStep] = useState(0);
    const messages = [
        "Escaneando o prato...",
        "Identificando alimentos...",
        "Pesando cada item...",
        "Analisando gorduras e sódio...",
        "Finalizando relatório técnico..."
    ];

    // Reset automático ao entrar na aba
    useFocusEffect(
        useCallback(() => {
            resetForm();
        }, [])
    );

    const resetForm = () => {
        setImage(null);
        setStatus('idle');
        setResult(null);
        setStep(0);
    };

    // Animação da Timeline de Status
    useEffect(() => {
        let timer;
        if (status === 'analyzing') {
            timer = setInterval(() => {
                setStep(s => (s < messages.length - 1 ? s + 1 : s));
            }, 1800);
        }
        return () => clearInterval(timer);
    }, [status]);

    const handlePickImage = async (useCamera = false) => {
        const options = { mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.8 };
        const res = useCamera 
            ? await ImagePicker.launchCameraAsync(options) 
            : await ImagePicker.launchImageLibraryAsync(options);

        if (!res.canceled) setImage(res.assets[0]);
    };

    const sendToAI = async () => {
        if (!image) return;
        setStatus('analyzing');
        setStep(0);

        const formData = new FormData();
        formData.append('file', {
            uri: image.uri,
            name: 'meal.jpg',
            type: 'image/jpeg',
        });

        try {
            const { data } = await api.post('/meal-logs', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            setResult(data);
            setStatus('result');
            if (refreshProfile) refreshProfile(); 
            
        } catch (err) {
            console.error(err);
            setStatus('idle');
            Alert.alert("Erro", "Falha na conexão com o servidor. Verifique seu backend.");
        }
    };

    // --- TELA DE CARREGAMENTO (TIMELINE) ---
    if (status === 'analyzing') {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#4CAF50" />
                <Text style={styles.statusTitle}>Análise Rigorosa</Text>
                <View style={styles.timeline}>
                    {messages.map((m, i) => (
                        <View key={i} style={styles.stepItem}>
                            <View style={[styles.dot, i <= step && styles.dotActive]} />
                            <Text style={[styles.stepText, i <= step && styles.stepActive]}>{m}</Text>
                        </View>
                    ))}
                </View>
            </View>
        );
    }

    // --- TELA DE RESULTADO (DETALHADO) ---
    if (status === 'result' && result) {
        const { macros, description, items } = result;
        return (
            <ScrollView 
                style={styles.containerResult}
                contentContainerStyle={{ paddingBottom: 160 }} 
            >
                <Image source={{ uri: image.uri }} style={styles.imgFull} />
                <View style={styles.cardResult}>
                    <Text style={styles.aiTitle}>Relatório do Nutricionista</Text>
                    <Text style={styles.aiDesc}>{description}</Text>

                    <Text style={styles.subTitle}>Composição por Item:</Text>
                    {items?.map((item, index) => (
                        <View key={index} style={styles.itemRow}>
                            <Text style={styles.itemName}>{item.name}</Text>
                            <View style={styles.itemLine} />
                            <Text style={styles.itemWeight}>{item.weight}g</Text>
                        </View>
                    ))}

                    <View style={styles.divider} />

                    <Text style={styles.subTitle}>Macronutrientes Totais:</Text>
                    <View style={styles.grid}>
                        <MacroBox label="Kcal" val={macros.calories} color="#FF9800" />
                        <MacroBox label="Prot" val={macros.protein} color="#F44336" />
                        <MacroBox label="Carb" val={macros.carbs} color="#2196F3" />
                        <MacroBox label="Gord" val={macros.fats} color="#FFC107" />
                        <DetailBox label="Fibras" val={macros.fiber} unit="g" color="#4CAF50" />
                    </View>

                

                    <TouchableOpacity style={styles.btnDone} onPress={() => navigation.navigate('Dashboard')}>
                        <Text style={styles.btnText}>Confirmar e Salvar</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity style={styles.btnCancel} onPress={resetForm}>
                        <Text style={styles.btnCancelText}>Descartar e Repetir</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        );
    }

    // --- TELA INICIAL (UPLOAD) ---
    return (
        <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 120 }}>
            <Text style={styles.header}>Registrar Comida</Text>
            
            <TouchableOpacity style={styles.uploadArea} onPress={() => handlePickImage(true)}>
                {image ? (
                    <Image source={{ uri: image.uri }} style={styles.imgPreview} />
                ) : (
                    <View style={styles.empty}>
                        <Ionicons name="camera" size={70} color="#CCC" />
                        <Text style={styles.emptyTxt}>Tire uma foto de cima do prato</Text>
                    </View>
                )}
            </TouchableOpacity>

            <View style={styles.row}>
                <TouchableOpacity style={styles.btnSec} onPress={() => handlePickImage(false)}>
                    <Text style={styles.btnSecTxt}>Galeria</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                    style={[styles.btnMain, !image && { opacity: 0.5 }]} 
                    onPress={sendToAI} 
                    disabled={!image}
                >
                    <Text style={styles.btnText}>Analisar Nutrientes</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
}

// Sub-componentes internos
const MacroBox = ({ label, val, color }) => (
    <View style={styles.box}>
        <Text style={[styles.boxVal, { color }]}>{val}</Text>
        <Text style={styles.boxLab}>{label}</Text>
    </View>
);

const DetailBox = ({ label, val, unit, color }) => (
    <View style={[styles.box, { width: '30%', backgroundColor: '#FFF', borderWidth: 1, borderColor: '#EEE' }]}>
        <Text style={[styles.boxVal, { color, fontSize: 14 }]}>{val}{unit}</Text>
        <Text style={styles.boxLab}>{label}</Text>
    </View>
);
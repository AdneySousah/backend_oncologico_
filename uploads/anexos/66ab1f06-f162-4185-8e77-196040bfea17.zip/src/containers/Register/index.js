import { StatusBar } from 'expo-status-bar';
import {  Text, TouchableOpacity, View } from 'react-native';
import { styles } from './styles';
import Button from '../../components/Button';
import { useNavigation } from '@react-navigation/native';
export default function Register() {

  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text>Registro</Text>
      
      <Button>Registrar</Button>
      <TouchableOpacity onPress={()=> navigation.navigate('Login')}>
        <Text>Voltar ao Login</Text>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}



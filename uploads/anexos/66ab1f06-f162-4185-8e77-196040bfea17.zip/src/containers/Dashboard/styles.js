import { StyleSheet, Dimensions } from 'react-native';
import { themes } from '../../styles/themes'; // Assumindo que você tem seu arquivo de cores

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FA', // Um cinza bem claro para dar contraste com os cards brancos
    },
    header: {
        paddingHorizontal: 25,
        paddingTop: 60,
        paddingBottom: 25,
        backgroundColor: themes.colors.primary || '#4A90E2', // Cor principal do seu app
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
    },
    welcome: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    subtitle: {
        fontSize: 16,
        color: 'rgba(255, 255, 255, 0.8)',
        marginTop: 5,
        marginBottom:15
    },
    statsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        marginTop: -30, // Faz os cards "subirem" sobre o header
    },
    card: {
        backgroundColor: '#FFFFFF',
        width: (width / 2) - 30, // Calcula metade da tela com espaçamento
        padding: 20,
        borderRadius: 20,
        marginBottom: 20,
        // Sombra para iOS
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
        // Sombra para Android
        elevation: 5,
        alignItems: 'center',
    },
    cardLabel: {
        fontSize: 12,
        color: '#7B7B7B',
        fontWeight: '600',
        textTransform: 'uppercase',
        marginBottom: 8,
    },
    cardValue: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#333',
    },
    cardSub: {
        fontSize: 12,
        color: themes.colors.primary || '#4A90E2',
        marginTop: 4,
        fontWeight: '500',
    },
    infoSection: {
        paddingHorizontal: 25,
        marginTop: 10,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 15,
    },
    infoText: {
        fontSize: 15,
        color: '#666',
        backgroundColor: '#FFFFFF',
        padding: 15,
        borderRadius: 12,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: '#EEE',
    },
    containerMetas:{
        justifyContent:'center',
        alignItems:'center'
    }
});
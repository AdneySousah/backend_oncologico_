import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useProfile } from '../../hooks/ProfileContext';
import { styles } from './styles';
import MacroCircle from '../../components/MacroCircle';

export default function Dashboard() {
    const { profileData } = useProfile();

    if (!profileData) return null;

    const goals = {
        calories: Math.round(profileData.tmb),
        protein: Math.round(profileData.weight * 2), // 2g por kg
        carbs: Math.round(profileData.weight * 4),    // 4g por kg
        fats: Math.round(profileData.weight * 0.8),  // 0.8g por kg
        fibers: 25 // Meta fixa padrão
    };


    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.welcome}>Olá, {profileData.first_name}!</Text>
                <Text style={styles.subtitle}>Confira sua saúde hoje:</Text>
            </View>

            {/* Cards de Métricas (Calculadas no seu Controller) */}
            <View style={styles.statsGrid}>
                <View style={styles.card}>
                    <Text style={styles.cardLabel}>Seu IMC</Text>
                    <Text style={styles.cardValue}>{profileData.imc.toFixed(1)}</Text>
                    <Text style={styles.cardSub}>{getImcStatus(profileData.imc)}</Text>
                </View>

                <View style={styles.card}>
                    <Text style={styles.cardLabel}>Taxa Metabólica (TMB)</Text>
                    <Text style={styles.cardValue}>{Math.round(profileData.tmb)}</Text>
                    <Text style={styles.cardSub}>kcal/dia</Text>
                </View>
            </View>

            {/* Informações de Perfil */}
            <View style={styles.infoSection}>
                <Text style={styles.sectionTitle}>Dados Atuais</Text>
                <Text style={styles.infoText}>Peso: {profileData.weight}kg</Text>
                <Text style={styles.infoText}>Altura: {profileData.heigh}cm</Text>
                <Text style={styles.infoText}>Nível: {profileData.activity_level}</Text>
            </View>

            <View style={styles.containerMetas}>
                <Text style={styles.sectionTitle}>Metas Diárias</Text>

                <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around' }}>

                    <MacroCircle
                        label="Calorias"
                        value={0} // Pegar do banco de refeições futuramente
                        target={goals.calories}
                        color="#FF9800"
                        percentage={10}
                    />
                    <MacroCircle
                        label="Proteína"
                        value={0}
                        target={goals.protein}
                        color="#F44336"
                        percentage={0}
                    />
                    <MacroCircle
                        label="Carbos"
                        value={0}
                        target={goals.carbs}
                        color="#2196F3"
                        percentage={0}
                    />
                    <MacroCircle
                        label="Gorduras"
                        value={0}
                        target={goals.fats}
                        color="#FFEB3B"
                        percentage={0}
                    />
                    <MacroCircle
                        label="Fibras"
                        value={0}
                        target={goals.fibers}
                        color="#4CAF50"
                        percentage={0}
                    />
                </View>
            </View>
        </ScrollView>
    );
}

// Função auxiliar simples para o IMC
function getImcStatus(imc) {
    if (imc < 18.5) return 'Abaixo do peso';
    if (imc < 25) return 'Peso normal';
    if (imc < 30) return 'Sobrepeso';
    return 'Obesidade';
}
import {useState } from 'react';
import { TextInput, View, Text, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { showMessage } from 'react-native-flash-message';
import { Ionicons } from '@expo/vector-icons';

import { styles } from './styles';
import { themes } from '../../styles/themes';
import { useAuth } from '../../hooks/AuthContext';
import PageLayout from '../../components/SafeArea';
import Button from '../../components/Button';
import Loading from '../../components/Loading';

export default function Login() {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(true);
    const [rememberMe, setRememberMe] = useState(false);

    const { login, awaitTime } = useAuth();



    const navigation = useNavigation();



    async function HandleLogin() {
        if (!email || !password) {
            showMessage({
                message: "Preencha todos os campos corretamente",
                type: "warning",
            });
            return;
        }
        try {
            // Lembrar de passar o remember aqui
            await login(email, password);

            showMessage({
                message: "Login realizado com sucesso",
                type: "success",
            });

            navigation.navigate('ProfileSetup');
            
        } catch (error) {
            showMessage({
                message: "Erro ao fazer login",
                type: "danger",
            });
        }
    }

    if (awaitTime === true) {
        return (
          <Loading/>
        )
    }

    return (
        <PageLayout style={styles.container}>
            <StatusBar style="auto" />

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={{ width: '100%', alignItems: 'center' }}
            >
                <View style={styles.header}>
                    <Text style={styles.title}>Zephyr Health</Text>
                    <Text style={styles.subtitle}>Sua saúde em boas mãos.</Text>
                </View>

                <View style={styles.form}>
                    <TextInput
                        style={[styles.input, styles.inputNormal]}
                        placeholder='Digite seu e-mail'
                        placeholderTextColor={themes.colors.placeholder}
                        onChangeText={setEmail}
                        autoCapitalize='none'
                        keyboardType='email-address'
                    />

                    <View style={styles.passwordContainer}>
                        <TextInput
                            style={[styles.input, { flex: 1 }]}
                            placeholder='Digite sua senha'
                            placeholderTextColor={themes.colors.placeholder}
                            onChangeText={setPassword}
                            secureTextEntry={showPassword}
                            autoCapitalize='none'
                        />
                        <TouchableOpacity
                            style={styles.eyeIcon}
                            onPress={() => setShowPassword(!showPassword)}
                        >
                            <Ionicons
                                name={showPassword ? "eye-off-outline" : "eye-outline"}
                                size={22}
                                color={themes.colors.textLight}
                            />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity
                        style={styles.rememberContainer}
                        onPress={() => setRememberMe(!rememberMe)}
                    >
                        <Ionicons
                            name={rememberMe ? "checkbox" : "square-outline"}
                            size={24}
                            color={rememberMe ? themes.colors.primary : themes.colors.textLight}
                        />
                        <Text style={styles.rememberText}>Manter conectado</Text>
                    </TouchableOpacity>

                    <Button onPress={() => HandleLogin()} style={styles.loginButton}>
                        Login
                    </Button>
                </View>

                <View style={styles.registerContainer}>
                    <Text style={styles.registerText}>Ainda não tem conta?</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('Register')}>
                        <Text style={styles.registerButtonText}>Registrar</Text>
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </PageLayout>
    );
}
import { StyleSheet } from "react-native";
import { themes } from '../../styles/themes';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: themes.colors.background,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: themes.spacing.large,
    },
    header: {
        alignItems: 'center',
        marginBottom: themes.spacing.xl,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: themes.colors.primary,
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 16,
        color: themes.colors.textLight,
        textAlign: 'center',
    },
    form: {
        width: '100%',
        backgroundColor: themes.colors.surface,
        padding: themes.spacing.large,
        borderRadius: themes.borderRadius.medium,
        elevation: 4, // Sombra Android
        shadowColor: "#000", // Sombra iOS
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    passwordContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: '100%',
        backgroundColor: themes.colors.background,
        borderRadius: themes.borderRadius.small,
        borderWidth: 1,
        borderColor: themes.colors.border,
        marginBottom: themes.spacing.medium,
    },
    input: {
        height: 55,
        borderRadius: themes.borderRadius.small,
        paddingHorizontal: themes.spacing.medium,
        color: themes.colors.text,
        fontSize: 16,
    },
    inputNormal: { // Para o email que não tem o ícone de olho
        width: '100%',
        borderWidth: 1,
        borderColor: themes.colors.border,
        backgroundColor: themes.colors.background,
        marginBottom: themes.spacing.medium,
    },
    eyeIcon: {
        paddingHorizontal: themes.spacing.medium,
    },
    rememberContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: themes.spacing.large,
    },
    rememberText: {
        marginLeft: 8,
        color: themes.colors.text,
        fontSize: 14,
    },
    loginButton: {
        backgroundColor: themes.colors.primary,
        height: 55,
        borderRadius: themes.borderRadius.small,
        justifyContent: 'center',
        alignItems: 'center',
    },
    registerContainer: {
        marginTop: themes.spacing.xl,
        flexDirection: 'row',
        alignItems: 'center',
    },
    registerText: {
        color: themes.colors.textLight,
        fontSize: 15,
    },
    registerButtonText: {
        color: themes.colors.accent,
        fontWeight: 'bold',
        marginLeft: 5,
    },

 
});
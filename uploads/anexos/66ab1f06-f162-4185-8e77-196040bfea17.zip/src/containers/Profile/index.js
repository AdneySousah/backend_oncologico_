import React, { useState, useRef } from "react";
import {
    Text, TextInput, View, Animated,
    Dimensions, TouchableOpacity, Pressable
} from "react-native";
import { Picker } from '@react-native-picker/picker';
import Checkbox from 'expo-checkbox';

import PageLayout from "../../components/SafeArea";
import Button from "../../components/Button";
import { themes } from '../../styles/themes';
import { styles } from "./styles";
import { maskDate, formatDateToBackend } from "../../utils/dateFormatter";

import { useProfile } from "../../hooks/ProfileContext";
import { useNavigation } from "@react-navigation/native";

const { width } = Dimensions.get('window');

export default function ProfileSetup() {
    const [step, setStep] = useState(0);

    // Estados do Formulário
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [birthDate, setBirthDate] = useState('');
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [gender, setGender] = useState(null);
    const [activityLevel, setActivityLevel] = useState(null);
    const [isChecked, setChecked] = useState(false);

    const { createProfile } = useProfile()

    const navigation = useNavigation()
    // Valor da animação
    const slideAnim = useRef(new Animated.Value(0)).current;

    const totalSteps = 4;

    const animateTransition = (direction) => {
        // Sai da tela
        Animated.timing(slideAnim, {
            toValue: direction === 'next' ? -width : width,
            duration: 200,
            useNativeDriver: true,
        }).start(() => {
            // Muda o step
            if (direction === 'next') setStep(s => s + 1);
            else setStep(s => s - 1);

            // Prepara para entrar (reseta posição oposta)
            slideAnim.setValue(direction === 'next' ? width : -width);

            // Entra na tela
            Animated.spring(slideAnim, {
                toValue: 0,
                friction: 8,
                tension: 40,
                useNativeDriver: true,
            }).start();
        });
    };

    const handleNext = () => {
        if (step < totalSteps) animateTransition('next');
    };

    const handleBack = () => {
        if (step > 0) animateTransition('back');
    };

    const handleDateChange = (text) => {
        const maskedText = maskDate(text);
        setBirthDate(maskedText);
    };

    async function HandleProfile() {
        const dateForApi = formatDateToBackend(birthDate);

        const profilePayload = {
            firstName,
            lastName,
            birthDate: dateForApi,
            height: Number(height), // Garante que vai como número
            weight: Number(weight), // Garante que vai como número
            gender,
            activityLevel,
            acceptedTerms: isChecked
        };


        try{
        await createProfile(profilePayload)
       
        }
        catch(err){
            console.log(err)
        }
      
    }

    const renderStep = () => {
        switch (step) {
            case 0:
                return (
                    <View>
                        <Text style={styles.label}>Como podemos te chamar?</Text>
                        <TextInput
                            style={styles.input}
                            onChangeText={setFirstName}
                            placeholder="Seu primeiro nome"
                            value={firstName}
                        />
                        <View style={{ height: 15 }} />
                        <TextInput
                            style={styles.input}
                            onChangeText={setLastName}
                            placeholder="Seu sobrenome"
                            value={lastName}
                        />
                    </View>
                );
            case 1:
                return (
                    <View>
                        <Text style={styles.label}>Qual sua data de nascimento?</Text>
                        <TextInput
                            style={styles.input}
                            onChangeText={handleDateChange}
                            value={birthDate}
                            keyboardType="numeric"
                            maxLength={10}
                            placeholder="DD/MM/AAAA"
                        />
                    </View>
                );
            case 2:
                return (
                    <View>
                        <Text style={styles.label}>Suas medidas atuais</Text>
                        <TextInput
                            style={styles.input}
                            onChangeText={setHeight}
                            placeholder="Altura em cm (ex: 175)"
                            keyboardType="numeric"
                        />
                        <View style={{ height: 15 }} />
                        <TextInput
                            style={styles.input}
                            onChangeText={setWeight}
                            placeholder="Peso (ex: 80.5)"
                            keyboardType="numeric"
                        />
                    </View>
                );
            case 3:
                return (
                    <View>
                        <Text style={styles.label}>Sobre o seu perfil</Text>
                        <View style={styles.pickerContainer}>
                            <Picker
                                selectedValue={gender}
                                onValueChange={(v) => setGender(v)}
                                dropdownIconColor={themes.colors.primary}
                                mode="dropdown"
                            >
                                <Picker.Item label="Selecione o gênero" value={null} color="#999" />
                                <Picker.Item label="Masculino" value="MALE" />
                                <Picker.Item label="Feminino" value="FEMALE" />
                            </Picker>
                        </View>
                        <View style={styles.pickerContainer}>
                            <Picker
                                selectedValue={activityLevel}
                                onValueChange={(v) => setActivityLevel(v)}
                                dropdownIconColor={themes.colors.primary}
                                mode="dropdown"
                            >
                                <Picker.Item label="Nível de Atividade" value={null} color="#999" />
                                <Picker.Item label="Sedentário" value="SEDENTARY" />
                                <Picker.Item label="Leve" value="LIGHT" />
                                <Picker.Item label="Moderado" value="MODERATE" />
                                <Picker.Item label="Ativo" value="ACTIVE" />
                                <Picker.Item label="Muito Ativo" value="VERY_ACTIVE" />
                            </Picker>
                        </View>
                    </View>
                );
            case 4:
                return (
                    <View>
                        <Text style={styles.label}>Quase lá!</Text>
                        <View style={styles.checkboxContainer}>
                            <Checkbox
                                value={isChecked}
                                onValueChange={setChecked}
                                color={isChecked ? themes.colors.primary : undefined}
                            />
                            <Pressable onPress={() => setChecked(!isChecked)}>
                                <Text style={styles.checkboxText}>
                                    Eu aceito os <Text style={styles.linkText}>Termos e Condições</Text>
                                </Text>
                            </Pressable>
                        </View>
                        <Button onPress={HandleProfile} disabled={!isChecked}>
                            Finalizar Cadastro
                        </Button>
                    </View>
                );
            default:
                return null;
        }
    };

    return (
        <PageLayout style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Finalize o seu cadastro</Text>

                {/* Barra de Progresso */}
                <View style={styles.progressContainer}>
                    <Animated.View
                        style={[
                            styles.progressBar,
                            { width: `${((step + 1) / (totalSteps + 1)) * 100}%` }
                        ]}
                    />
                </View>
            </View>

            {/* Container Animado */}
            <Animated.View style={[styles.stepContainer, { transform: [{ translateX: slideAnim }] }]}>
                {renderStep()}
            </Animated.View>

            {/* Navegação */}
            <View style={styles.footer}>
                {step > 0 ? (
                    <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                        <Text style={styles.backButtonText}>Voltar</Text>
                    </TouchableOpacity>
                ) : <View />}

                {step < totalSteps && (
                    <Button onPress={handleNext} style={{ width: 120 }}>Próximo</Button>
                )}
            </View>
        </PageLayout>
    );
}
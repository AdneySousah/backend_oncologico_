import { StyleSheet, Dimensions } from "react-native";
import { themes } from '../../styles/themes';

const { width } = Dimensions.get('window');

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: themes.colors.background,
        paddingHorizontal: themes.spacing.large,
        justifyContent: 'center'
    },
    header: {
        marginBottom: themes.spacing.xl,
        alignItems: 'center',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: themes.colors.primary,
        textAlign: 'center',
    },
    // Barra de Progresso
    progressContainer: {
        width: '100%',
        height: 8,
        backgroundColor: themes.colors.border,
        borderRadius: 4,
        marginTop: themes.spacing.medium,
        overflow: 'hidden',
    },
    progressBar: {
        height: '100%',
        backgroundColor: themes.colors.accent,
        borderRadius: 4,
    },
    // Container da Animação
    stepContainer: {
        width: width - (themes.spacing.large * 2), // Largura dinâmica
        backgroundColor: themes.colors.surface,
        borderRadius: themes.borderRadius.medium,
        padding: themes.spacing.large,
        elevation: 4,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    inputGroup: {
        marginBottom: themes.spacing.medium,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: themes.colors.text,
        marginBottom: 8,
    },
    input: {
        width: '100%',
        height: 55,
        backgroundColor: themes.colors.background,
        borderRadius: themes.borderRadius.small,
        paddingHorizontal: themes.spacing.medium,
        borderWidth: 1,
        borderColor: themes.colors.border,
        color: themes.colors.text,
        fontSize: 16,
    },
    pickerContainer: {
        backgroundColor: themes.colors.background,
        borderRadius: themes.borderRadius.small,
        borderWidth: 1,
        borderColor: themes.colors.border,
        marginBottom: themes.spacing.medium,
        overflow: 'hidden',
    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: themes.spacing.medium,
    },
    checkboxText: {
        marginLeft: 10,
        color: themes.colors.text,
        fontSize: 14,
    },
    linkText: {
        color: themes.colors.primary,
        fontWeight: 'bold',
        textDecorationLine: 'underline',
    },
    footer: {
        marginTop: themes.spacing.large,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    backButton: {
        padding: 15,
        justifyContent: 'center',
    },
    backButtonText: {
        color: themes.colors.textLight,
        fontWeight: '600',
    }
});
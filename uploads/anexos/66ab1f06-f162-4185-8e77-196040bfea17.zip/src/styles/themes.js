export const themes = {
    colors: {
        primary: '#2D6A4F',
        secondary: '#95D5B2',
        accent: '#FF8C42',
        background: '#F8F9FA',
        surface: '#FFFFFF',
        text: '#1B4332',
        textLight: '#52B788',
        success: '#52B788',
        warning: '#FFB703',
        error: '#D90429',
        border: '#E9ECEF',
        placeholder: '#A0AEC0',
    },
    spacing: {
        small: 8,
        medium: 16,
        large: 24,
        xl: 40,
    },
    borderRadius: {
        small: 8,
        medium: 12,
        full: 99,
    }
}
import React from 'react';
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import { useAuth } from "../hooks/AuthContext";
import { useProfile } from "../hooks/ProfileContext";
import Loading from "../components/Loading";

// Telas
import Login from "../containers/Login";
import Register from "../containers/Register";
import ProfileSetup from "../containers/Profile";
// IMPORTANTE: Agora importamos as rotas do App, não mais o Dashboard direto
import { AppRoutes } from './tabNavigator.routes'; 

const Stack = createNativeStackNavigator();

export default function RoutesApp() {
    const { user, awaitTime } = useAuth();
    const { profileData, loadingProfile } = useProfile();

    if (awaitTime || (user && loadingProfile)) {
        return <Loading />;
    }

    return (
        <NavigationContainer>
            <Stack.Navigator 
                screenOptions={{ 
                    headerShown: false, 
                    animation: 'fade' 
                }}
            >
                {user ? (
                    !profileData ? (
                        <Stack.Group>
                            <Stack.Screen name='ProfileSetup' component={ProfileSetup} />
                        </Stack.Group>
                    ) : (
                        // AQUI ESTÁ A MUDANÇA:
                        // Quando logado e com perfil, ele carrega o AppRoutes (com a TabBar)
                        <Stack.Group>
                            <Stack.Screen name='MainApp' component={AppRoutes} />
                        </Stack.Group>
                    )
                ) : (
                    <Stack.Group>                        
                        <Stack.Screen name='Login' component={Login} />
                        <Stack.Screen name='Register' component={Register} />
                    </Stack.Group>
                )}
            </Stack.Navigator>
        </NavigationContainer>
    );
}
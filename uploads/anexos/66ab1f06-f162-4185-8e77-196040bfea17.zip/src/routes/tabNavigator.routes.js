import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import TabBar from '../components/TabBar'; // O componente que criamos

import Dashboard from '../containers/Dashboard';
import MealLog from '../containers/MealLog';

const Tab = createBottomTabNavigator();

const Placeholder = () => null;

export function AppRoutes() {
    return (
        <Tab.Navigator
            tabBar={props => <TabBar {...props} />}
            screenOptions={{ headerShown: false }}
        >
            <Tab.Screen name="Dashboard" component={Dashboard} />
            <Tab.Screen name="Refeição" component={MealLog} />
            <Tab.Screen name="Diário" component={Placeholder} />
            <Tab.Screen name="Perfil" component={Placeholder} />
        </Tab.Navigator>
    );
}